# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mex']

package_data = \
{'': ['*'], 'mex': ['.pytest_cache/*', '.pytest_cache/v/cache/*']}

entry_points = \
{'console_scripts': ['mex = mex.main:main']}

setup_kwargs = {
    'name': 'mex',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Bietola',
    'author_email': 'dincio.montesi@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
